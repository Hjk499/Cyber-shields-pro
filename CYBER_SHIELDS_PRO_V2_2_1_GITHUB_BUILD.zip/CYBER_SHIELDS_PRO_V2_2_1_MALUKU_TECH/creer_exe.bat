@echo off
cd /d "%~dp0"
echo Installation des dependances...
python -m pip install -r requirements.txt
python -m pip install pyinstaller
echo Creation de Cyber Shields Pro...
python -m PyInstaller --noconfirm --clean --windowed --name Cyber_Shields_Pro --icon=cyber_shields.ico --add-data "cyber_shields_logo.png;." --add-data "cyber_shields.ico;." cyber_shields_pro.py
echo.
echo Termine. Ouvrez dist\Cyber_Shields_Pro\Cyber_Shields_Pro.exe
pause
