"""
CYBER SHIELDS - MALUKU TECH
Functional MVP: system monitoring, basic network diagnostics, process listing,
threshold alerts, and CSV report export.

This is NOT antivirus software and does not detect/remove malware.
"""
import csv
import platform
import socket
import subprocess
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import datetime

try:
    import psutil
except ImportError:
    psutil = None

APP_NAME = "CYBER SHIELDS"
COMPANY = "MALUKU TECH"

class CyberShieldsApp:
    def __init__(self, root):
        self.root = root
        self.root.title(f"{APP_NAME} | {COMPANY}")
        self.root.geometry("1000x680")
        self.root.minsize(820, 560)
        self.running = True
        self.latest = {}
        self._build_ui()
        self.refresh_all()

    def _build_ui(self):
        header = ttk.Frame(self.root, padding=12)
        header.pack(fill="x")
        ttk.Label(header, text=APP_NAME, font=("Segoe UI", 22, "bold")).pack(side="left")
        ttk.Label(header, text=COMPANY, font=("Segoe UI", 10)).pack(side="right")

        self.tabs = ttk.Notebook(self.root)
        self.tabs.pack(fill="both", expand=True, padx=12, pady=(0, 12))

        self.dashboard = ttk.Frame(self.tabs, padding=12)
        self.network = ttk.Frame(self.tabs, padding=12)
        self.processes = ttk.Frame(self.tabs, padding=12)
        self.tabs.add(self.dashboard, text="Tableau de bord")
        self.tabs.add(self.network, text="Réseau")
        self.tabs.add(self.processes, text="Processus")

        self.status_var = tk.StringVar(value="Initialisation…")
        ttk.Label(self.dashboard, text="État du système", font=("Segoe UI", 15, "bold")).pack(anchor="w")
        self.metrics = {}
        grid = ttk.Frame(self.dashboard)
        grid.pack(fill="x", pady=12)
        labels = [("CPU", "cpu"), ("Mémoire RAM", "ram"), ("Disque système", "disk")]
        for i, (label, key) in enumerate(labels):
            card = ttk.LabelFrame(grid, text=label, padding=12)
            card.grid(row=0, column=i, sticky="nsew", padx=6)
            grid.columnconfigure(i, weight=1)
            val = tk.StringVar(value="—")
            ttk.Label(card, textvariable=val, font=("Segoe UI", 20, "bold")).pack()
            bar = ttk.Progressbar(card, length=220, maximum=100, mode="determinate")
            bar.pack(fill="x", pady=8)
            self.metrics[key] = (val, bar)

        info = ttk.LabelFrame(self.dashboard, text="Informations de l'ordinateur", padding=10)
        info.pack(fill="x", pady=8)
        self.info_var = tk.StringVar()
        ttk.Label(info, textvariable=self.info_var, justify="left").pack(anchor="w")
        ttk.Label(self.dashboard, textvariable=self.status_var).pack(anchor="w", pady=8)

        controls = ttk.Frame(self.dashboard)
        controls.pack(anchor="w", pady=6)
        ttk.Button(controls, text="Actualiser maintenant", command=self.refresh_all).pack(side="left", padx=4)
        ttk.Button(controls, text="Exporter un rapport CSV", command=self.export_report).pack(side="left", padx=4)

        ttk.Label(self.network, text="Diagnostic réseau de base", font=("Segoe UI", 15, "bold")).pack(anchor="w")
        row = ttk.Frame(self.network)
        row.pack(fill="x", pady=12)
        ttk.Label(row, text="Hôte à tester :").pack(side="left")
        self.host_entry = ttk.Entry(row, width=28)
        self.host_entry.insert(0, "8.8.8.8")
        self.host_entry.pack(side="left", padx=8)
        ttk.Button(row, text="Tester la connexion", command=self.run_ping).pack(side="left")
        self.net_output = tk.Text(self.network, height=18, wrap="word")
        self.net_output.pack(fill="both", expand=True)
        self.net_output.insert("end", "Le test utilise la commande ping du système.\n")

        ttk.Label(self.processes, text="Processus en cours", font=("Segoe UI", 15, "bold")).pack(anchor="w")
        ttk.Button(self.processes, text="Actualiser la liste", command=self.refresh_processes).pack(anchor="w", pady=8)
        cols = ("pid", "name", "cpu", "memory")
        self.tree = ttk.Treeview(self.processes, columns=cols, show="headings", height=20)
        for col, title, width in [
            ("pid", "PID", 90), ("name", "Nom du processus", 420),
            ("cpu", "CPU %", 120), ("memory", "Mémoire %", 130)
        ]:
            self.tree.heading(col, text=title)
            self.tree.column(col, width=width, anchor="w")
        self.tree.pack(fill="both", expand=True)

        footer = ttk.Label(self.root, text="MVP de diagnostic et surveillance — ne remplace pas un antivirus ou un audit professionnel.",
                           anchor="center")
        footer.pack(fill="x", pady=(0, 6))

    def refresh_all(self):
        if psutil is None:
            self.status_var.set("Module psutil absent. Installez les dépendances avec : pip install -r requirements.txt")
            return
        try:
            cpu = psutil.cpu_percent(interval=0.3)
            ram = psutil.virtual_memory().percent
            disk = psutil.disk_usage("C:\\" if platform.system() == "Windows" else "/").percent
            values = {"cpu": cpu, "ram": ram, "disk": disk}
            self.latest = values
            for key, value in values.items():
                var, bar = self.metrics[key]
                var.set(f"{value:.1f} %")
                bar["value"] = value
            self.info_var.set(
                f"Système : {platform.system()} {platform.release()} ({platform.machine()})\n"
                f"Ordinateur : {platform.node()}\n"
                f"Processeurs logiques : {psutil.cpu_count()}\n"
                f"Adresse locale : {self.get_local_ip()}\n"
                f"Dernière mesure : {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}"
            )
            alerts = [f"{k.upper()} élevé ({v:.0f} %)" for k, v in values.items() if v >= 85]
            self.status_var.set("ALERTE : " + " | ".join(alerts) if alerts else "État : aucun seuil critique détecté (seuil d'alerte 85 %).")
            self.refresh_processes()
        except Exception as exc:
            self.status_var.set(f"Erreur de lecture du système : {exc}")

    def get_local_ip(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "Indisponible"

    def run_ping(self):
        host = self.host_entry.get().strip()
        if not host or any(c.isspace() for c in host):
            messagebox.showwarning("Hôte invalide", "Saisissez un nom d'hôte ou une adresse IP valide.")
            return
        self.net_output.insert("end", f"\n--- Test vers {host} ---\n")
        self.net_output.see("end")
        def worker():
            try:
                flag = "-n" if platform.system() == "Windows" else "-c"
                result = subprocess.run(["ping", flag, "4", host], capture_output=True, text=True, timeout=15)
                output = result.stdout or result.stderr or "Aucune sortie retournée."
            except Exception as exc:
                output = f"Échec du test : {exc}"
            self.root.after(0, lambda: self._append_ping(output))
        threading.Thread(target=worker, daemon=True).start()

    def _append_ping(self, output):
        self.net_output.insert("end", output + "\n")
        self.net_output.see("end")

    def refresh_processes(self):
        if psutil is None or not hasattr(self, "tree"):
            return
        for item in self.tree.get_children():
            self.tree.delete(item)
        rows = []
        for p in psutil.process_iter(["pid", "name", "memory_percent"]):
            try:
                cpu = p.cpu_percent(interval=None)
                mem = p.info.get("memory_percent") or 0
                rows.append((p.info["pid"], p.info.get("name") or "Inconnu", cpu, mem))
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        rows.sort(key=lambda x: x[2], reverse=True)
        for pid, name, cpu, mem in rows[:150]:
            self.tree.insert("", "end", values=(pid, name, f"{cpu:.1f}", f"{mem:.1f}"))

    def export_report(self):
        if not self.latest:
            messagebox.showinfo("Rapport", "Actualisez d'abord les mesures.")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("Fichier CSV", "*.csv")],
            initialfile=f"CyberShields_Rapport_{datetime.now().strftime('%Y%m%d_%H%M')}.csv"
        )
        if not path:
            return
        try:
            with open(path, "w", newline="", encoding="utf-8-sig") as f:
                writer = csv.writer(f, delimiter=";")
                writer.writerow(["Produit", APP_NAME])
                writer.writerow(["Entreprise", COMPANY])
                writer.writerow(["Date", datetime.now().isoformat(timespec="seconds")])
                writer.writerow(["Ordinateur", platform.node()])
                writer.writerow(["Système", platform.platform()])
                writer.writerow([])
                writer.writerow(["Indicateur", "Valeur (%)"])
                for key, value in self.latest.items():
                    writer.writerow([key.upper(), f"{value:.1f}"])
            messagebox.showinfo("Rapport créé", f"Rapport enregistré :\n{path}")
        except Exception as exc:
            messagebox.showerror("Erreur", str(exc))

def main():
    root = tk.Tk()
    app = CyberShieldsApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
