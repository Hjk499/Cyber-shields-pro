# CYBER SHIELDS PRO V2.2 – MALUKU TECH

Application graphique Windows de surveillance et de diagnostic informatique.

## Fonctions présentes
- Tableau de bord CPU, RAM et disque avec centre d'alertes et historique récent.
- Surveillance des ressources avec seuil d'avertissement à 85 % et critique à 95 %.
- Diagnostic réseau : test Ping et consultation des connexions/ports en écoute.
- Maintenance : analyse des fichiers temporaires et nettoyage avec confirmation.
- Liste des processus, journaux d'incidents et export CSV.
- Logo PNG dans l'interface et icône ICO pour Windows.

## Installation et lancement
1. Extraire entièrement le ZIP dans un dossier du PC Windows.
2. Installer Python 3 si nécessaire (cocher « Add Python to PATH » pendant l'installation).
3. Double-cliquer sur `installer_et_lancer.bat` pour installer `psutil` et lancer l'application.

## Création de l'EXE
Double-cliquer sur `creer_exe.bat`. Le programme construit une distribution PyInstaller dans `dist\\Cyber_Shields_Pro\\`. Garder le dossier complet `Cyber_Shields_Pro` : ne pas déplacer uniquement le fichier EXE.

## Données et limites
Les journaux sont enregistrés dans le dossier `CyberShields` du profil Windows de l'utilisateur. Le nettoyage concerne uniquement les fichiers temporaires accessibles du compte et demande confirmation. Certains fichiers verrouillés sont ignorés.

Cyber Shields Pro est un outil de surveillance et de diagnostic. Il ne remplace pas un antivirus, un pare-feu ou un audit de cybersécurité et ne garantit pas la détection de toutes les menaces. Les ports signalés sont à examiner, pas une preuve d'intrusion.

## Vérification de cette livraison
Le démarrage de l'interface a été testé dans un environnement graphique virtuel : chargement du logo, affichage de la version 2.2.0, construction du tableau de bord, du centre d'alertes et du module Maintenance & diagnostic. Un essai sur un vrai PC Windows reste nécessaire avant déploiement commercial.


## Moteur de détection local expérimental (V2.2.1)

La rubrique « Maintenance & diagnostic » comporte désormais trois commandes : analyse rapide, choix d'un dossier et analyse du dossier utilisateur. Le moteur recherche le fichier de test EICAR et quelques indicateurs heuristiques simples. Il ne supprime ni ne met en quarantaine aucun fichier. Les résultats heuristiques sont des éléments à examiner, pas des infections confirmées.

**Limite importante :** cette fonction n'est pas un antivirus complet et ne garantit pas la détection des malwares. Elle ne remplace pas Microsoft Defender ni une solution de sécurité maintenue. Une base de signatures fiable, des mises à jour sécurisées, des tests indépendants et une validation Windows sont nécessaires avant toute commercialisation comme antivirus.
